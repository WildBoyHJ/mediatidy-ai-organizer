"""AI 识别 → TMDB 核对 → 整理。

流程：选择文件/目录 →（必要时）后台扫描 → 分批 AI 识别文件名 → TMDB 搜索与身份核对
→ 同剧一致性检查 → 草稿审阅或直接整理 → 等待宿主任务 → 归档结果。

契约要点：
* 只有 action/continuation 能调用 AI 与整理能力，query 只读 storage。
* 每批一次模型请求，singleRequest 不自动重发；失败保留已完成结果并继续。
* AI 不可用时退回本地文件名解析，不把「没有模型」当成「没有文件」。
"""
from __future__ import annotations

import time
from typing import Any

from mt_plugin import Plugin as BasePlugin, Context, SDKError, action, continuation, query, ui

import identify
import naming
import notify

DEFAULT_BATCH = 8
DEFAULT_TOLERANCE = 1
DEFAULT_MINUTES = 20
MAX_FILES = 500
AI_CHAT_LIMIT = 78
# 每批 8 个 × 78 次 = 624，理论够 500 个；但失败重试会消耗额度，
# 留出余量，默认每轮最多处理这么多文件。
SAFE_FILES = 400
TMDB_SEARCH_LIMIT = 500


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class Plugin(BasePlugin):
    # ---------------------------------------------------------------- 生命周期

    def validate_config(self, config: dict, ctx: Context) -> None:
        profile = config.get("profileId")
        if profile is not None and (not isinstance(profile, int) or profile <= 0):
            raise SDKError("请选择一个整理方案", "INVALID_CONFIG", path="config.profileId")
        mode = config.get("mode")
        if mode not in (None, "", "draft", "direct"):
            raise SDKError("提交方式只能是草稿审阅或直接整理", "INVALID_CONFIG", path="config.mode")
        batch = config.get("batchSize")
        if batch is not None and not 1 <= int(batch) <= 10:
            raise SDKError("每批文件数需在 1-10 之间", "INVALID_CONFIG", path="config.batchSize")

    def on_init(self, ctx: Context) -> None:
        saved = ctx.mt.storage.get(key="settings")
        if not saved["found"]:
            ctx.mt.storage.set(key="settings", value={"schemaVersion": 1})
        ctx.mt.log(level="info", message="AI 识别整理已初始化")

    # ---------------------------------------------------------------- 页面

    def get_page(self, ctx: Context) -> dict:
        # 关键：profile 与提交方式必须 bind 到 input 空间（input.profileId / input.mode），
        # 宿主会在 invoke 时把这些值合并进动作参数。用 state 传值不会进 inputSchema，
        # 会报「Schema 缺少必填字段 profileId」。
        running = ui.expr("or",
                          ui.expr("eq", ui.ref("run.status"), "queued"),
                          ui.expr("eq", ui.ref("run.status"), "running"))
        ready = ui.expr("and",
                        ui.expr("not", running),
                        ui.ref("input.profileId"),
                        ui.expr("gt", ui.ref("stats.selections"), 0))
        return ui.page(
            ui.Alert(
                text="文件名与路径会发送到你配置的 AI 服务；识别结果还要经过 TMDB 核对才会进入整理。",
                tone="muted",
            ),
            ui.Card(
                ui.Text(text="1. 选择整理方案与提交方式"),
                ui.ProfilePicker(label="整理方案", bind="input.profileId"),
                ui.Select(label="提交方式", bind="input.mode", options=[
                    {"label": "草稿审阅（推荐）", "value": "draft"},
                    {"label": "直接整理", "value": "direct"},
                ]),
                ui.Text(text="2. 选择要处理的视频文件或目录"),
                ui.FilePicker(),
                ui.Button(
                    label="开始识别与整理",
                    onClick=[{"type": "invoke", "actionId": "start"}],
                    disabled=ui.expr("not", ready),
                ),
                ui.Text(text=ui.expr(
                    "if",
                    ui.expr("eq", ui.ref("stats.selections"), 0),
                    "请先选择文件或目录",
                    ui.expr("if", ui.ref("input.profileId"), "准备就绪，可以开始", "请选择整理方案"),
                ), tone="muted", size="sm"),
                title="开始",
            ),
            ui.Card(
                ui.Progress(
                    label=ui.ref("run.progress.message"),
                    value=ui.ref("run.progress.completed"),
                    total=ui.ref("run.progress.total"),
                ),
                ui.Text(
                    text=ui.expr(
                        "if",
                        running,
                        "运行中：进度条上显示当前阶段、已完成数量与正在处理的文件名。",
                        ui.ref("query.results.data.message"),
                    ),
                    tone="muted",
                    size="sm",
                ),
                title=ui.expr("if", running, "进度 · 运行中", "进度"),
            ),
            ui.Card(
                ui.Progress(
                    label=ui.ref("query.organize.data.message"),
                    value=ui.ref("query.organize.data.done"),
                    total=ui.ref("query.organize.data.total"),
                ),
                ui.Text(text=ui.ref("query.organize.data.current"), tone="primary", size="sm"),
                ui.Text(text=ui.ref("query.organize.data.hint"), tone="muted", size="sm"),
                ui.Table(
                    source=ui.ref("query.organize.data.items"),
                    rowKey="ref",
                    pageSize=10,
                    columns=[
                        {"label": "作品", "field": "label", "cells": []},
                        {"label": "状态", "field": "statusLabel", "cells": []},
                    ],
                ),
                ui.Text(
                    text="整理由 MT 执行，这里读任务状态汇总；刷新后更新（整轮结束后宿主会自动刷新）。",
                    tone="muted",
                    size="sm",
                ),
                ui.Button(
                    label="刷新整理进度",
                    variant="outline",
                    onClick=[{"type": "query", "queryId": "organize"},
                             {"type": "query", "queryId": "results"}],
                ),
                title="整理进度",
                visible=ui.expr(
                    "gt",
                    ui.expr("coalesce", ui.ref("query.organize.data.total"), 0),
                    0,
                ),
            ),
            ui.Card(
                ui.Table(
                    source=ui.ref("query.results.data.items"),
                    rowKey="id",
                    pageSize=20,
                    columns=[
                        {"label": "文件", "field": "name", "cells": []},
                        {"label": "识别作品", "field": "title", "cells": []},
                        {"label": "TMDB", "field": "tmdb", "cells": []},
                        {"label": "季集", "field": "episodeLabel", "cells": []},
                        {"label": "状态", "field": "statusLabel", "cells": []},
                        {"label": "说明", "field": "reason", "cells": []},
                        {"label": "AI 原始回答", "field": "aiRaw", "cells": []},
                    ],
                ),
                ui.Stack(
                    ui.Button(label="刷新", variant="outline", onClick=[
                        {"type": "set", "path": "state.cursor", "value": ""},
                        {"type": "query", "queryId": "results"},
                    ]),
                    ui.Button(label="下一页", variant="outline",
                              disabled=ui.expr("not", ui.ref("query.results.data.nextCursor")),
                              onClick=[{"type": "set", "path": "state.cursor",
                                        "value": ui.ref("query.results.data.nextCursor")}]),
                    ui.Button(label="查看草稿", variant="outline",
                              onClick=[{"type": "host", "name": "reviewDrafts"}]),
                    direction="row", gap="sm",
                ),
                title="识别结果",
            ),
            ui.Card(ui.RunHistory(), title="运行记录"),
            state={"cursor": "", "mode": "draft"},
            queries=[{"id": "results", "name": "results", "input": {"cursor": ui.ref("state.cursor")}},
                     {"id": "organize", "name": "organize", "input": {}}],
        )

    # ---------------------------------------------------------------- 入口动作

    @action("start")
    def start(self, input: dict, ctx: Context) -> dict:
        profile_id = self._profile_id(input, ctx)
        mode = self._mode(input, ctx)
        files, dirs = self._selected(ctx)
        if not files and not dirs:
            raise SDKError("请先选择视频文件或包含视频的目录", "NO_FILES")

        # 续接会换 run_id，但根流程 flow_id 不变；跨调用状态一律挂在 flow_id 上。
        flow_key = ctx.flow_id
        options = self._options(ctx)
        # 方案与选项必须落盘：续接时的 input 由宿主回填，不能当成可信参数来源。
        self._save_flow(ctx, flow_key, {
            "profileId": profile_id,
            "mode": mode,
            "options": options,
            "scanRefs": [],
            "stage": "scan" if dirs else "identify",
        })
        self._write_summary(ctx, flow_key, {
            "status": "scanning" if dirs else "identifying",
            "profileId": profile_id,
            "mode": mode,
            "counts": {"total": len(files), "matched": 0, "failed": 0, "submitted": 0},
            "message": "已开始",
            "createdAt": _now(),
        })
        ctx.mt.storage.set(key="currentRun", value=flow_key)

        if not dirs:
            return self._pipeline(ctx, flow_key, files, profile_id, mode, options)

        refs = []
        for index, folder in enumerate(dirs):
            task = ctx.mt.files.scan(
                root_id=folder["rootId"],
                path=folder["path"],
                video_only=True,
                limit=SAFE_FILES,
                idempotency_key=f"{ctx.flow_id}:scan:{index}",
            )
            refs.append(task["ref"])
        self._patch_flow(ctx, flow_key, {"scanRefs": refs, "scanParent": ctx.run_id})
        self._save_pending(ctx, flow_key, files)
        ctx.mt.log(level="info", message=f"已提交 {len(refs)} 个扫描任务，等待完成后继续识别")
        ctx.mt.tasks.wait(refs=refs, completion={
            "action": "after-scan",
            "input": {"flowKey": flow_key},
        })
        return {"waiting": True, "flowKey": flow_key, "scans": len(refs)}

    @continuation("after-scan")
    def after_scan(self, input: dict, ctx: Context) -> dict:
        flow_key = ctx.flow_id
        flow = self._load_flow(ctx, flow_key)
        if not flow:
            raise SDKError("找不到本次运行的流程记录，请重新开始", "FLOW_MISSING")
        profile_id = int(flow.get("profileId") or 0)
        requested = flow.get("mode")
        mode = "direct" if requested == "direct" else "draft"
        options = flow.get("options") or self._options(ctx)

        # 续接事件必须与原流程登记的扫描任务一致，避免串到别的运行。
        tasks = (ctx.event or {}).get("tasks") or []
        expected = set(flow.get("scanRefs") or [])
        received = {task.get("ref") for task in tasks}
        if expected and received != expected:
            raise SDKError("续接事件与本次扫描任务不匹配", "FLOW_MISMATCH")

        files = self._load_pending(ctx, flow_key)
        truncated = 0
        failed_scans = 0
        partial_scans = 0
        capped = 0
        for task in tasks:
            # 扫描可能因为达到容量上限而 failed，但已经产出的条目仍然可读。
            # 先取结果再判断成败，不要把扫到的文件丢掉。
            status = task.get("status")
            offset = 0
            while True:
                page = ctx.mt.tasks.items(ref=task["ref"], offset=offset, limit=100)
                for item in page.get("items", []):
                    record = item.get("file")
                    if record and not record.get("isDir"):
                        files.append(record)
                following = page.get("nextOffset") or 0
                if not following or following <= offset:
                    break
                offset = following
            if status != "done":
                completed = int(task.get("completed") or 0)
                if completed >= SAFE_FILES:
                    capped += 1
                    ctx.mt.log(level="warn",
                               message=f"目录里的视频超过单轮上限 {SAFE_FILES} 个，已用扫描到的 {completed} 个；"
                                       f"剩余文件请分批重新选择")
                elif files:
                    partial_scans += 1
                    ctx.mt.log(level="warn",
                               message=f"扫描任务 {task.get('ref', '')} 状态 {status}，使用已扫描到的部分结果")
                else:
                    failed_scans += 1
                    ctx.mt.log(level="warn", message=f"扫描任务 {task.get('ref', '')} 状态 {status}，无可用结果")

        deduped: list[dict] = []
        seen: set[str] = set()
        for record in files:
            if record["ref"] in seen:
                continue
            seen.add(record["ref"])
            if not naming.is_video(record.get("name", "")):
                continue
            deduped.append(record)
        if len(deduped) > MAX_FILES:
            truncated = len(deduped) - MAX_FILES
            deduped = deduped[:MAX_FILES]

        if failed_scans:
            ctx.mt.log(level="warn", message=f"{failed_scans} 个扫描任务未成功，结果可能不完整")
        if truncated:
            ctx.mt.log(level="warn", message=f"超过单轮上限，已截断 {truncated} 个文件")
        if not deduped:
            self._patch_summary(ctx, flow_key, {"status": "done", "message": "扫描没有找到视频文件"})
            return {"count": 0, "message": "扫描没有找到视频文件"}

        return self._pipeline(ctx, flow_key, deduped, profile_id, mode, options)

    # ---------------------------------------------------------------- 主流程

    def _pipeline(self, ctx: Context, flow_key: str, files: list[dict],
                  profile_id: int, mode: str, options: dict) -> dict:
        profile = self._check_profile(ctx, profile_id)
        info = ctx.mt.runtime.info()
        limits = info.get("limits") or {}
        max_files = int(limits.get("maxWorkflowFiles") or 100)
        cap = min(max_files, SAFE_FILES)
        if len(files) > cap:
            ctx.mt.log(level="warn",
                       message=f"文件数 {len(files)} 超过本轮上限 {cap}（宿主 {max_files}、AI 额度安全线 {SAFE_FILES}），"
                               f"只处理前 {cap} 个；其余请分批重新选择")
            files = files[:cap]

        deadline = time.monotonic() + options["minutes"] * 60
        batch_size = options["batch"]
        state: dict = {
            "aiCalls": 0,
            "tmdbSearches": 0,
            "tmdbDetails": 0,
            "aiUnavailable": "",
            "truncatedPreview": 0,
        }

        capabilities = self._capabilities(ctx)
        ai_ok = capabilities.get("chat", {}).get("available") is True
        if not ai_ok:
            state["aiUnavailable"] = capabilities.get("chat", {}).get("reason", "unavailable")
            ctx.mt.log(level="warn",
                       message=f"AI 不可用（{state['aiUnavailable']}），改用本地文件名解析")

        results: list[dict] = []
        total = len(files)
        self._report(ctx, "准备识别", 0, total, f"共 {total} 个文件")

        for start in range(0, len(files), batch_size):
            if time.monotonic() > deadline:
                for record in files[start:]:
                    results.append(self._record(record, status="failed", reason="超出识别时间上限，未处理"))
                ctx.mt.log(level="warn", message="达到识别时间上限，剩余文件未识别")
                break
            ctx.mt.runtime.checkpoint()
            chunk = files[start:start + batch_size]
            head = chunk[0].get("name", "") if chunk else ""
            tail = f" 等 {len(chunk)} 个" if len(chunk) > 1 else ""
            self._report(ctx, "识别中", len(results), total, f"正在处理 {head}{tail}")
            if ai_ok and int(state["aiCalls"]) < AI_CHAT_LIMIT:
                records, state = self._identify_batch(ctx, chunk, options, state)
            else:
                records = [self._local_record(item) for item in chunk]
            results.extend(records)
            # 把本批已确定的同剧身份喂给下一批，避免后续批次换到另一个 TMDB 条目
            state["seriesHint"] = identify.series_hint(results)
            done = min(start + len(chunk), total)
            self._report(ctx, "已识别", done, total,
                         chunk[-1].get("name", "") if chunk else "")
            self._persist(ctx, flow_key, results)
            ctx.mt.runtime.result(value={"counts": self._counts(results), "message": "识别中"})

        # TMDB 核对
        results, state = self._verify_all(ctx, results, options, state, deadline)
        self._persist(ctx, flow_key, results)

        # 同剧一致性
        results = self._check_series(results)
        self._persist(ctx, flow_key, results)

        counts = self._counts(results)
        ready = [item for item in results if item["status"] == "matched"]
        summary = {
            "status": "submitting" if ready else "done",
            "profileId": profile_id,
            "mode": mode,
            "counts": counts,
            "aiUnavailable": state["aiUnavailable"],
            "message": f"识别完成：可整理 {len(ready)}，失败 {counts['failed']}",
            "profile": profile.get("name", ""),
        }

        if not ready:
            self._patch_summary(ctx, flow_key, summary)
            ctx.mt.log(level="info", message="没有可整理的文件，保留识别结果")
            self._notify_result(ctx, counts, mode, profile.get("name", ""), results)
            return {"counts": counts, "message": summary["message"]}

        if mode == "draft":
            drafted = self._submit_drafts(ctx, flow_key, ready, profile_id)
            counts = self._counts(results)
            summary["counts"] = counts
            summary["status"] = "done"
            summary["message"] = f"已生成 {drafted} 条整理草稿，请在草稿页核对后确认"
            self._patch_summary(ctx, flow_key, summary)
            self._notify_result(ctx, counts, mode, profile.get("name", ""), results)
            ctx.mt.runtime.result(value=summary)
            return {"counts": counts, "drafts": drafted, "message": summary["message"]}

        refs = self._submit_direct(ctx, flow_key, ready, profile_id)
        counts = self._counts(results)
        summary["counts"] = counts
        if not refs:
            summary["status"] = "done"
            summary["message"] = "整理任务提交失败，请查看日志"
            self._patch_summary(ctx, flow_key, summary)
            self._notify_result(ctx, counts, mode, profile.get("name", ""), results)
            return {"counts": counts, "message": summary["message"]}
        summary["status"] = "waiting"
        summary["message"] = f"已提交 {len(refs)} 个整理任务，等待完成"
        self._patch_summary(ctx, flow_key, summary)
        self._persist(ctx, flow_key, results)
        ctx.mt.log(level="info", message=summary["message"])
        ctx.mt.tasks.wait(refs=refs, completion={"action": "collect", "input": {"flowKey": flow_key}})
        return {"counts": counts, "waiting": True, "tasks": len(refs)}

    # ---------------------------------------------------------------- 识别

    def _identify_batch(self, ctx: Context, chunk: list[dict],
                        options: dict, state: dict) -> tuple[list[dict], dict]:
        valid = {item["ref"] for item in chunk}
        messages = identify.build_messages(chunk, options["extra"], state.get("seriesHint", ""))
        started = time.monotonic()

        # 先按用户设置尝试。原生联网搜索需要宿主开启 AI 联网；宿主没开时
        # 会自动降级为普通调用，因为「没有联网」不等于「不能用 AI」。
        want_native = bool(options["nativeSearch"]) and not state.get("nativeDisabled")
        response = None
        try:
            response = ctx.mt.ai.chat(
                messages=messages,
                single_request=True,
                native_web_search=want_native,
            )
        except SDKError as error:
            state["aiCalls"] += 1
            if want_native and error.code in ("AI_NATIVE_SEARCH_DISABLED",
                                              "AI_NATIVE_SEARCH_NOT_PERFORMED",
                                              "AI_REQUEST_REJECTED"):
                state["nativeDisabled"] = error.code
                ctx.mt.log(level="warn",
                           message=f"宿主未启用 AI 联网搜索（{error.code}），"
                                   "本次起改用普通 AI 调用；识别仍会继续，但缺少网页交叉验证")
                try:
                    response = ctx.mt.ai.chat(messages=messages, single_request=True)
                except SDKError as retry_error:
                    state["aiCalls"] += 1
                    ctx.mt.log(level="warn",
                               message=f"AI 调用失败 {retry_error.code}，改用本地文件名解析")
                    state["aiUnavailable"] = retry_error.code
                    return [self._local_record(item) for item in chunk], state
                state["aiCalls"] += 1
            else:
                ctx.mt.log(level="warn", message=f"AI 批次失败 {error.code}，改用本地解析")
                if error.code in ("AI_NATIVE_SEARCH_DISABLED", "AI_NATIVE_SEARCH_NOT_PERFORMED",
                                  "AI_REQUEST_REJECTED", "AI_TIMEOUT", "AI_PROTOCOL_ERROR"):
                    state["aiUnavailable"] = error.code
                return [self._local_record(item) for item in chunk], state
        else:
            state["aiCalls"] += 1
        elapsed = int((time.monotonic() - started) * 1000)

        message = response.get("message") or {}
        raw_content = message.get("content") if isinstance(message, dict) else None
        text = raw_content if isinstance(raw_content, str) else ""
        entries, diagnostics = identify.parse_response(text, valid)
        shown = identify.preview(text)
        if shown["truncated"]:
            state["truncatedPreview"] += 1

        by_ref = {entry["ref"]: entry for entry in entries}
        records: list[dict] = []
        for item in chunk:
            entry = by_ref.get(item["ref"])
            if entry is None:
                fallback = self._local_record(item)
                fallback["reason"] = "模型未返回该文件，已用本地解析"
                fallback["preview"] = shown
                records.append(fallback)
                continue
            record = self._record(item, status="identified")
            record.update({
                "title": entry["title"],
                "originalTitle": entry["originalTitle"],
                "year": entry["year"],
                "mediaType": entry["mediaType"],
                "tmdbId": entry["tmdbId"],
                "season": entry["season"],
                "episode": entry["episode"],
                "multiEpisode": entry["multiEpisode"],
                "confidence": entry["confidence"],
                "sources": entry["sources"],
                "aiUsed": True,
                "modelMs": elapsed,
                "reason": entry["reason"],
            })
            if not record["tmdbId"]:
                hinted = naming.tmdb_id_from_path(item.get("path", ""), item.get("name", ""))
                if hinted:
                    record["tmdbId"] = hinted
                    note = f"使用目录标注的 TMDB ID {hinted}"
                    record["reason"] = f"{record['reason']}；{note}" if record["reason"] else note
            if not record["title"]:
                record["status"] = "unrecognized"
                record["reason"] = "模型没有给出作品名"
            record["preview"] = shown
            records.append(record)

        if diagnostics.get("error"):
            ctx.mt.log(level="warn", message=f"解析失败：{diagnostics['error']}")
        if diagnostics.get("unknownRefs"):
            ctx.mt.log(level="warn", message=f"丢弃 {diagnostics['unknownRefs']} 条陌生引用")
        if diagnostics.get("noTmdbId"):
            # 把模型原始输出打出来（截断），否则无法判断是模型不听话还是解析出错
            sample = identify.sanitize(text, 400) if text else "（空回答）"
            ctx.mt.log(level="warn",
                       message=f"{diagnostics['noTmdbId']} 个文件模型未给出 TMDB ID；"
                               f"原始回答片段：{sample}")
        if diagnostics.get("missingIds"):
            ctx.mt.log(level="warn", message=f"{diagnostics['missingIds']} 个文件模型未返回条目")
        native_raw: Any = response.get("nativeWebSearch")
        sources = (native_raw.get("sources") or []) if isinstance(native_raw, dict) else []
        if sources:
            ctx.mt.log(level="debug", message=f"本轮搜索来源 {len(sources)} 条")
        return records, state

    def _local_record(self, item: dict) -> dict:
        parsed = naming.parse(item.get("name", ""))
        record = self._record(item, status="identified")
        record.update({
            "title": parsed["title"],
            "originalTitle": "",
            "year": parsed["year"],
            "mediaType": parsed["mediaType"],
            "season": parsed["season"],
            "episode": parsed["episode"],
            "confidence": 0.0,
            "aiUsed": False,
            "reason": "本地文件名解析",
        })
        # 目录名里的 tmdb-xxxx 是明确标注，不用 AI 猜
        hinted = naming.tmdb_id_from_path(item.get("path", ""), item.get("name", ""))
        if hinted:
            record["tmdbId"] = hinted
            record["reason"] = f"使用目录标注的 TMDB ID {hinted}"
        if not record["title"]:
            record["status"] = "unrecognized"
            record["reason"] = "文件名无法解析出作品名"
        return record

    # ---------------------------------------------------------------- TMDB 核对

    def _verify_all(self, ctx: Context, results: list[dict], options: dict,
                    state: dict, deadline: float) -> tuple[list[dict], dict]:
        """核对 AI 给出的 tmdbId。插件不替模型挑候选——那是同名误判的主要来源。"""
        details: dict[tuple[int, str], dict | None] = {}
        seasons_cache: dict[int, list[int]] = {}
        tolerance = options["tolerance"]

        total = len(results)
        for index, record in enumerate(results):
            if record["status"] != "identified":
                continue
            if time.monotonic() > deadline:
                record["status"] = "failed"
                record["reason"] = "超出识别时间上限，未核对 TMDB"
                continue
            ctx.mt.runtime.checkpoint()
            self._report(ctx, "核对 TMDB", index + 1, total, record.get("name", ""))

            media_type = record.get("mediaType")
            tmdb_id = int(record.get("tmdbId") or 0)

            # 有 ID 但类型未知：用 TMDB 反查类型，而不是直接放弃。
            if media_type not in ("movie", "tv") and tmdb_id > 0:
                media_type = self._resolve_media_type(ctx, tmdb_id, details, state)
                if media_type:
                    record["mediaType"] = media_type
            if media_type not in ("movie", "tv"):
                # 保留模型给出的具体原因（如「避免猜测」），不要用通用文案覆盖
                record["status"] = "unrecognized"
                record["reason"] = record.get("reason") or (
                    "无法判断是电影还是剧集"
                    if tmdb_id <= 0 else "TMDB 上找不到该 ID 对应的电影或剧集"
                )
                record["tmdbId"] = tmdb_id if tmdb_id > 0 else 0
                continue
            if tmdb_id <= 0:
                # 模型没给 ID 时，用名称+年份做一次受控搜索：
                # 只有「唯一一个候选通过名称与年份校验」才采纳，多个候选一律不猜。
                resolved, why = self._resolve_unique(
                    ctx, record, details, state, tolerance)
                if resolved:
                    tmdb_id = resolved
                    record["tmdbId"] = tmdb_id
                    record["reason"] = f"{record.get('reason') or ''}；按名称与年份唯一匹配到 TMDB {tmdb_id}".strip("；")
                else:
                    # 保留识别阶段的原因（如「本地文件名解析」），追加兜底搜索的结论
                    base = record.get("reason") or ""
                    record["status"] = "unrecognized"
                    record["reason"] = f"{base}；{why}" if base and why else (base or why or "模型没有给出可靠的 TMDB ID")
                    continue

            identity = (tmdb_id, media_type)
            if identity not in details:
                if state["tmdbDetails"] >= TMDB_SEARCH_LIMIT:
                    record["status"] = "failed"
                    record["reason"] = "TMDB 查询次数用尽"
                    continue
                try:
                    details[identity] = ctx.mt.tmdb.detail(id=tmdb_id, media_type=media_type)
                except SDKError as error:
                    if error.code == "CANCELLED":
                        raise
                    ctx.mt.log(level="warn", message=f"TMDB 详情失败 {error.code}")
                    details[identity] = None
                state["tmdbDetails"] += 1

            detail = details[identity]
            if not detail:
                record["status"] = "failed"
                record["reason"] = "TMDB 详情读取失败，未生成整理请求"
                continue

            # 1) ID 与类型必须与返回一致
            if int(detail.get("id") or 0) != tmdb_id or detail.get("mediaType") != media_type:
                record["status"] = "identity_conflict"
                record["reason"] = "TMDB 返回的 ID 或类型与识别结论不一致"
                continue

            # 2) 名称必须有交集；模型给的别名可能对不上，但 TMDB 的标题应至少命中其一
            if not identify.title_matches(
                [detail.get("title", ""), detail.get("originalTitle", "")],
                [record.get("title", ""), record.get("originalTitle", "")],
            ):
                record["status"] = "identity_conflict"
                record["reason"] = (
                    f"识别为「{record.get('title') or '未知'}」，但 TMDB ID {tmdb_id} "
                    f"对应「{detail.get('title') or detail.get('originalTitle') or '未知作品'}」"
                )
                record["tmdbId"] = tmdb_id
                continue

            # 3) 年份容差；模型给的年份为 0 时以 TMDB 为准
            year = self._year(detail.get("year", ""))
            if record["year"] and year and abs(record["year"] - year) > tolerance:
                record["status"] = "identity_conflict"
                record["reason"] = f"年份不一致（识别 {record['year']}，TMDB {year}）"
                record["tmdbId"] = tmdb_id
                continue

            # 4) 季集合法性：用 TMDB 真实季列表核对，而不是只看有没有数字
            if media_type == "tv":
                record["tmdbId"] = tmdb_id
                if record.get("multiEpisode"):
                    record["status"] = "needs_review"
                    record["reason"] = "多集合集，需人工拆分季集"
                    continue
                season = int(record.get("season") or 0)
                episode = int(record.get("episode") or 0)
                if tmdb_id not in seasons_cache:
                    seasons_cache[tmdb_id] = self._seasons_of(ctx, tmdb_id, state) or []
                listed = seasons_cache[tmdb_id]
                if not season:
                    real = [item for item in listed if item > 0]
                    if len(real) == 1:
                        # 只有一季：TMDB 编号就是第 1 季，可以确定
                        season = real[0]
                        record["season"] = season
                    elif not listed:
                        # 拿不到季列表：按第 1 季处理并标记待复核
                        season = 1
                        record["season"] = 1
                        record["status"] = "needs_review"
                        record["reason"] = "文件名无季号且 TMDB 季列表不可用，暂按第 1 季处理，请核对"
                        if not episode:
                            continue
                    else:
                        record["status"] = "needs_review"
                        record["reason"] = (
                            "无法确定季号，需人工指定。TMDB 已列出："
                            + ", ".join(f"S{item:02d}" for item in listed)
                        )
                        continue
                if not episode:
                    record["status"] = "needs_review"
                    record["reason"] = f"匹配到《{record['title']}》（S{season:02d}）但无法识别集数"
                    continue
                # 季号是否真实存在：避免「S02 但该剧只有一季」这类文件名错误。
                # 只在拿到非空季列表时判定，空列表/查询失败一律跳过，避免把
                # 「拿不到数据」误判成「季不存在」。
                if tmdb_id not in seasons_cache:
                    seasons_cache[tmdb_id] = self._seasons_of(ctx, tmdb_id, state) or []
                listed = seasons_cache[tmdb_id]
                if listed and season not in listed:
                    record["status"] = "needs_review"
                    record["reason"] = (
                        f"TMDB 未列出第 {season} 季，已列出："
                        + ", ".join(f"S{item:02d}" for item in listed)
                    )
                    continue
            else:
                record["season"] = 0
                record["episode"] = 0

            record["tmdbId"] = tmdb_id
            record["title"] = detail.get("title") or record["title"]
            record["originalTitle"] = detail.get("originalTitle") or record.get("originalTitle", "")
            record["year"] = year or record["year"]
            record["status"] = "matched"
            record["reason"] = ""
        return results, state

    @staticmethod
    def _resolve_unique(ctx: Context, record: dict,
                        details: dict[tuple[int, str], dict | None],
                        state: dict, tolerance: int) -> tuple[int, str]:
        """模型未给 ID 时，按名称+年份搜索；只有唯一候选通过校验才采纳。

        返回 (tmdbId, 说明)。多个候选或没有候选时返回 (0, 原因)。
        """
        media_type = record.get("mediaType")
        title = record.get("title") or ""
        original = record.get("originalTitle") or ""
        if media_type not in ("movie", "tv") or not (title or original):
            return 0, ""
        if state.get("tmdbSearches", 0) >= TMDB_SEARCH_LIMIT:
            return 0, ""

        candidates: list[dict] = []
        seen: set[int] = set()
        for query in (title, original):
            if not query:
                continue
            state["tmdbSearches"] = state.get("tmdbSearches", 0) + 1
            try:
                found = ctx.mt.tmdb.search(query=query, media_type=media_type)
            except SDKError as error:
                if error.code == "CANCELLED":
                    raise
                continue
            for item in found if isinstance(found, list) else []:
                if not isinstance(item, dict):
                    continue
                item_id = int(item.get("id") or 0)
                if item_id <= 0 or item_id in seen:
                    continue
                if item.get("mediaType") and item["mediaType"] != media_type:
                    continue
                seen.add(item_id)
                candidates.append(item)

        if not candidates:
            return 0, "模型未给出 TMDB ID，按名称搜索也没有结果"

        # 只有同时满足「名称命中」和「年份容差」的候选才算数
        wanted = [title, original]
        year = int(record.get("year") or 0)
        valid: list[dict] = []
        for item in candidates:
            names = [item.get("title", ""), item.get("originalTitle", "")]
            if not identify.title_matches(names, wanted):
                continue
            item_year = Plugin._year(item.get("year", ""))
            if year and item_year and abs(year - item_year) > tolerance:
                continue
            valid.append(item)

        if len(valid) == 1:
            return int(valid[0]["id"]), ""
        if len(valid) > 1:
            listed = "、".join(
                f"{item.get('title') or item.get('originalTitle')}（{item.get('year') or '?'}，ID {item.get('id')}）"
                for item in valid[:4]
            )
            return 0, f"同名候选无法裁决，需人工确认：{listed}"
        return 0, "模型未给出 TMDB ID，按名称搜索到的候选都与名称或年份不符"

    @staticmethod
    def _resolve_media_type(ctx: Context, tmdb_id: int,
                            details: dict[tuple[int, str], dict | None], state: dict) -> str:
        """模型给了 ID 但类型未知时，用 TMDB 反查它到底是电影还是剧集。"""
        for candidate in ("movie", "tv"):
            key = (tmdb_id, candidate)
            if key not in details:
                if state["tmdbDetails"] >= TMDB_SEARCH_LIMIT:
                    return ""
                try:
                    details[key] = ctx.mt.tmdb.detail(id=tmdb_id, media_type=candidate)
                except SDKError as error:
                    if error.code == "CANCELLED":
                        raise
                    details[key] = None
                state["tmdbDetails"] += 1
            detail = details[key]
            if detail and int(detail.get("id") or 0) == tmdb_id:
                return candidate
        return ""

    @staticmethod
    def _seasons_of(ctx: Context, tmdb_id: int, state: dict) -> list[int] | None:
        """拉取该剧在 TMDB 已列出的季号。

        返回 None 表示查询不可用（失败或额度用尽）——此时跳过季号校验，不误拦。
        返回空列表表示 TMDB 确实没有列出任何季。
        """
        if state.get("seasonQueries", 0) >= 60:
            return None
        state["seasonQueries"] = state.get("seasonQueries", 0) + 1
        try:
            listed = ctx.mt.tmdb.season(id=tmdb_id, season=0)
        except SDKError as error:
            if error.code == "CANCELLED":
                raise
            ctx.mt.log(level="debug", message=f"季列表查询失败 {error.code}，跳过季号校验")
            return None
        if not isinstance(listed, list):
            return None
        return sorted({int(item) for item in listed if isinstance(item, int) and item >= 0})

    @staticmethod
    def _year(value) -> int:
        text = str(value or "").strip()
        digits = "".join(ch for ch in text if ch.isdigit())
        return int(digits[:4]) if len(digits) >= 4 else 0

    # ---------------------------------------------------------------- 同剧一致性

    @staticmethod
    def _check_series(results: list[dict]) -> list[dict]:
        """同授权根、同目录、同规范化剧名的多集必须指向同一个 TMDB 作品与季号。"""
        groups: dict[tuple[str, str, str], list[dict]] = {}
        for record in results:
            if record["status"] != "matched" or record["mediaType"] != "tv":
                continue
            path = record.get("path", "")
            folder = path.rsplit("/", 1)[0] if "/" in path else ""
            key = (record.get("rootId", ""), folder, naming.normalize(record.get("title", "")))
            groups.setdefault(key, []).append(record)
        for members in groups.values():
            if len(members) < 2:
                continue
            ids = {member.get("tmdbId") for member in members}
            seasons = {member.get("season") for member in members}
            if len(ids) > 1:
                for member in members:
                    member["status"] = "identity_conflict"
                    member["reason"] = "同剧跨批识别出不同 TMDB 作品，整组暂停"
            elif len(seasons) > 1:
                for member in members:
                    member["status"] = "identity_conflict"
                    member["reason"] = "同剧识别出不同季号，整组暂停"
        return results

    # ---------------------------------------------------------------- 提交

    def _submit_drafts(self, ctx: Context, flow_key: str, ready: list[dict], profile_id: int) -> int:
        created = 0
        total = len(ready)
        for start in range(0, len(ready), 100):
            chunk = ready[start:start + 100]
            self._report(ctx, "生成草稿", start, total,
                         f"正在处理 {chunk[0].get('name', '') if chunk else ''}")
            items = []
            for record in chunk:
                item = {
                    "fileRef": record["ref"],
                    "profileId": profile_id,
                    "tmdbId": int(record["tmdbId"]),
                    "mediaType": record["mediaType"],
                    "reason": "AI 识别并核对 TMDB",
                    "recognition": {
                        "title": record["title"] or record["name"],
                        "sources": "ai" if record.get("aiUsed") else "filename",
                    },
                }
                if record.get("originalTitle"):
                    item["recognition"]["originalTitle"] = record["originalTitle"]
                if record.get("year"):
                    item["recognition"]["year"] = int(record["year"])
                if record["mediaType"] == "tv":
                    item["season"] = int(record["season"])
                    item["episode"] = int(record["episode"])
                items.append(item)
            try:
                response = ctx.mt.organize.manual.prepare_batch(items=items)
            except SDKError as error:
                ctx.mt.log(level="error", message=f"草稿准备失败 {error.code}")
                for record in chunk:
                    record["status"] = "failed"
                    record["reason"] = f"草稿准备失败：{error.code}"
                continue
            prepared = {entry.get("fileRef"): entry for entry in response.get("items", [])
                        if isinstance(entry, dict)}
            for record in chunk:
                entry = prepared.get(record["ref"])
                if entry and entry.get("id"):
                    record["status"] = "submitted"
                    record["draftId"] = entry["id"]
                    record["reason"] = "已生成草稿，等待人工确认"
                    created += 1
                else:
                    record["status"] = "failed"
                    record["reason"] = "草稿未生成，请检查文件版本与方案"
            self._report(ctx, "草稿已生成", min(start + len(chunk), total), total,
                         chunk[-1].get("name", "") if chunk else "")
        self._persist(ctx, flow_key, ready)
        return created

    def _submit_direct(self, ctx: Context, flow_key: str, ready: list[dict], profile_id: int) -> list[str]:
        refs: list[str] = []
        total = len(ready)
        for index, record in enumerate(ready):
            ctx.mt.runtime.checkpoint()
            self._report(ctx, "提交整理", index, total, record.get("name", ""))
            key = f"{ctx.flow_id}:{record['ref']}:{record['tmdbId']}"
            payload = {
                "fileRef": record["ref"],
                "profileId": profile_id,
                "tmdbId": int(record["tmdbId"]),
                "mediaType": record["mediaType"],
                "idempotencyKey": key,
            }
            if record["mediaType"] == "tv":
                payload["season"] = int(record["season"])
                payload["episode"] = int(record["episode"])
            try:
                task = ctx.mt.organize.manual.run(payload)
            except SDKError as error:
                record["status"] = "failed"
                record["reason"] = f"提交失败：{error.code}"
                continue
            record["status"] = "submitted"
            record["taskRef"] = task["ref"]
            record["taskStatus"] = task.get("status", "queued")
            record["reason"] = "已入队"
            refs.append(task["ref"])
        self._patch_flow(ctx, flow_key, {"taskRefs": refs, "organizeParent": ctx.run_id,
                                         "stage": "organize"})
        self._persist(ctx, flow_key, ready)
        return refs

    @continuation("collect")
    def collect(self, input: dict, ctx: Context) -> dict:
        flow_key = ctx.flow_id
        flow = self._load_flow(ctx, flow_key)
        tasks = (ctx.event or {}).get("tasks") or []
        expected = set(flow.get("taskRefs") or [])
        if expected and {task.get("ref") for task in tasks} != expected:
            raise SDKError("续接事件与本次整理任务不匹配", "FLOW_MISMATCH")

        results = self._load(ctx, flow_key)
        by_ref = {record.get("taskRef"): record for record in results if record.get("taskRef")}
        settled = 0
        failed = 0
        for task in tasks:
            record = by_ref.get(task.get("ref"))
            if record is None:
                continue
            status = task.get("status", "")
            record["taskStatus"] = status
            if status == "done":
                record["status"] = "organized"
                record["reason"] = "整理完成"
                settled += 1
            elif status in ("failed", "cancelled", "interrupted", "outcome_unknown"):
                record["status"] = "failed"
                record["reason"] = f"整理任务 {status}"
                failed += 1
            else:
                record["reason"] = f"任务状态 {status}"
        self._persist(ctx, flow_key, results)
        counts = self._counts(results)
        message = f"整理结束：成功 {settled}，失败 {failed}"
        self._patch_summary(ctx, flow_key, {"status": "done", "counts": counts, "message": message})
        ctx.mt.runtime.result(value={"counts": counts, "message": message})
        ctx.mt.log(level="info", message=message)
        requested_mode = flow.get("mode")
        mode = "draft" if requested_mode == "draft" else "direct"
        stored = self._load_flow(ctx, flow_key).get("profileName")
        profile_name = stored if isinstance(stored, str) else ""
        self._notify_result(ctx, counts, mode, profile_name, results)
        return {"counts": counts, "settled": settled, "failed": failed}

    # ---------------------------------------------------------------- 查询

    @query("results")
    def results(self, input: dict, ctx: Context) -> dict:
        current = ctx.mt.storage.get(key="currentRun")
        if not current["found"]:
            return {"items": [], "nextCursor": "", "message": "尚未开始识别"}
        flow_key = current["value"]
        summary_entry = ctx.mt.storage.get(key=f"runs/{flow_key}/summary")
        summary = summary_entry["value"] if summary_entry["found"] else {}
        prefix = f"runs/{flow_key}/items/"
        cursor = input.get("cursor", "")
        if cursor and not cursor.startswith(prefix):
            cursor = ""
        page = ctx.mt.storage.list(prefix=prefix, cursor=cursor, limit=20, values=True)
        items = []
        for entry in page.get("items", []):
            record = entry.get("value") or {}
            items.append({
                "id": entry["key"],
                "name": record.get("name", ""),
                "title": record.get("title", ""),
                "tmdb": str(record.get("tmdbId") or ""),
                "episodeLabel": self._episode_label(record),
                "statusLabel": self._status_label(record.get("status", "")),
                "reason": record.get("reason", ""),
                "aiRaw": (record.get("preview") or {}).get("text", "")[:600],
            })
        counts = summary.get("counts") or {}
        message = summary.get("message") or "尚未开始识别"
        if counts:
            message = f"{message}（共 {counts.get('total', 0)}，可整理 {counts.get('matched', 0)}，" \
                      f"已提交 {counts.get('submitted', 0)}，失败 {counts.get('failed', 0)}）"
        return {"items": items, "nextCursor": page.get("nextCursor", ""), "message": message,
                "status": summary.get("status", "")}

    @query("organize")
    def organize(self, input: dict, ctx: Context) -> dict:
        """整理阶段的实时进度。

        整理由宿主执行，等待期间插件不在线（tasks.wait 后调用 SDK 会 FLOW_WAITING），
        所以这里读 tasks.list 的任务状态自行汇总；页面靠刷新按钮更新
        —— 宿主只在整轮运行结束后才自动刷新查询。
        """
        empty = {"total": 0, "done": 0, "failed": 0, "remaining": 0, "running": 0,
                 "pending": 0, "message": "尚未提交整理任务", "current": "",
                 "hint": "", "items": []}
        current = ctx.mt.storage.get(key="currentRun")
        if not current["found"]:
            return empty
        flow_key = current["value"]
        pairs = self._load_taskmap(ctx, flow_key)
        if not pairs:
            return {**empty, "message": "本轮没有整理任务（草稿模式，或没有可整理的文件）"}

        labels = {pair.get("ref", ""): pair.get("label", "") for pair in pairs}
        statuses = self._task_statuses(ctx, set(labels))
        done = failed = running = pending = 0
        current_label = ""
        active: list[dict] = []
        broken: list[dict] = []
        for ref, label in labels.items():
            status = statuses.get(ref, "")
            row = {"ref": ref, "label": label, "statusLabel": self._task_status_label(status)}
            if status == "done":
                done += 1
            elif status in ("failed", "cancelled", "interrupted", "outcome_unknown"):
                failed += 1
                broken.append(row)
            elif status == "running":
                running += 1
                active.append(row)
                if not current_label:
                    current_label = label
            else:
                pending += 1
                active.append(row)

        total = len(labels)
        remaining = total - done - failed
        if not current_label and active:
            current_label = active[0]["label"]
        if remaining <= 0:
            message = f"整理完成 {done}/{total}"
        elif current_label:
            message = f"整理中 {done}/{total} · 正在整理 {current_label}"
        else:
            message = f"整理中 {done}/{total} · 剩余 {remaining}"
        hint = (f"已完成 {done} · 失败 {failed} · 剩余 {remaining}"
                f"（进行中 {running} / 排队 {pending}）")
        return {"total": total, "done": done, "failed": failed, "remaining": remaining,
                "running": running, "pending": pending, "message": message,
                "current": current_label, "hint": hint,
                "items": (active + broken)[:10]}

    @staticmethod
    def _task_status_label(status: str) -> str:
        return {
            "running": "正在整理",
            "queued": "排队中",
            "submitting": "提交中",
            "waiting": "等待中",
            "done": "已完成",
            "failed": "失败",
            "cancelled": "已取消",
            "interrupted": "被中断",
            "outcome_unknown": "结果未知",
        }.get(status, "状态未知")

    @classmethod
    def _task_label(cls, record: dict) -> str:
        title = record.get("title") or record.get("name") or ""
        episode = cls._episode_label(record)
        if episode and episode != "-":
            title = f"{title} {episode}".strip()
        return title[:60]

    @classmethod
    def _load_taskmap(cls, ctx: Context, flow_key: str) -> list[dict]:
        """从已落盘的识别结果里取出 任务 ref → 片名 映射。

        识别结果每轮都会 _persist，提交整理后每条记录带 taskRef，
        所以不必另存一份映射 —— 也让升级前提交的旧运行照样能查到进度。
        """
        prefix = f"runs/{flow_key}/items/"
        pairs: list[dict] = []
        cursor = ""
        for _ in range(10):  # 单轮上限 400，100/页 → 最多 4 页
            page = ctx.mt.storage.list(prefix=prefix, cursor=cursor, limit=100, values=True)
            for entry in page.get("items", []):
                record = entry.get("value") or {}
                ref = record.get("taskRef")
                if ref:
                    pairs.append({"ref": ref, "label": cls._task_label(record)})
            cursor = page.get("nextCursor") or ""
            if not cursor:
                break
        return pairs

    @staticmethod
    def _task_statuses(ctx: Context, refs: set[str]) -> dict[str, str]:
        """分页扫 tasks.list，只留下本次提交的任务状态。"""
        found: dict[str, str] = {}
        cursor = ""
        for _ in range(20):
            page = ctx.mt.tasks.list(cursor=cursor, limit=100)
            for item in page.get("items", []):
                ref = item.get("ref")
                if ref in refs:
                    found[ref] = item.get("status") or ""
            cursor = page.get("nextCursor") or ""
            if not cursor or len(found) >= len(refs):
                break
        return found

    @staticmethod
    def _episode_label(record: dict) -> str:
        if record.get("mediaType") != "tv":
            return "-"
        season = record.get("season") or 0
        episode = record.get("episode") or 0
        return f"S{season:02d}E{episode:02d}" if season or episode else "-"

    @staticmethod
    def _status_label(status: str) -> str:
        return {
            "identified": "已识别",
            "matched": "已核对",
            "unrecognized": "未识别",
            "identity_conflict": "身份冲突",
            "needs_review": "需人工处理",
            "submitted": "已提交",
            "organized": "已完成",
            "failed": "失败",
        }.get(status, status or "未知")

    # ---------------------------------------------------------------- 辅助

    @staticmethod
    def _selected(ctx: Context) -> tuple[list[dict], list[dict]]:
        files: list[dict] = []
        dirs: list[dict] = []
        seen: set[str] = set()
        for item in ctx.files or []:
            if item.get("isDir"):
                dirs.append(item)
                continue
            if item["ref"] in seen:
                continue
            seen.add(item["ref"])
            if naming.is_video(item.get("name", "")):
                files.append(item)
        return files, dirs

    @staticmethod
    def _profile_id(input: dict, ctx: Context) -> int:
        # profile 是动作表单字段（type=profile），config 里不再声明
        raw = input.get("profileId")
        try:
            profile_id = int(raw) if raw is not None else 0
        except (TypeError, ValueError):
            profile_id = 0
        if profile_id <= 0:
            raise SDKError("请先在设置中选择一个整理方案", "NO_PROFILE")
        return profile_id

    @staticmethod
    def _mode(input: dict, ctx: Context) -> str:
        value = input.get("mode") or ctx.config.get("mode") or "draft"
        return "direct" if value == "direct" else "draft"

    @staticmethod
    def _options(ctx: Context) -> dict:
        config = ctx.config
        batch = config.get("batchSize")
        batch = int(batch) if isinstance(batch, (int, float)) else DEFAULT_BATCH
        tolerance = config.get("yearTolerance")
        tolerance = int(tolerance) if isinstance(tolerance, (int, float)) else DEFAULT_TOLERANCE
        minutes = config.get("maxMinutes")
        minutes = int(minutes) if isinstance(minutes, (int, float)) else DEFAULT_MINUTES
        extra = config.get("promptExtra") or ""
        return {
            "batch": max(1, min(10, batch)),
            "tolerance": max(0, min(5, tolerance)),
            "minutes": max(2, min(60, minutes)),
            "nativeSearch": bool(config.get("nativeSearch")),
            "extra": extra if isinstance(extra, str) else "",
            "minConfidence": 0.5,
        }

    def _check_profile(self, ctx: Context, profile_id: int) -> dict:
        """校验方案可用性。

        重要：**不检查 destination.writable**。本插件不申请 files.write，
        授权页因此不提供写入勾选项，方案的目标目录必然是 writable=false。
        真正的写入权限由宿主在执行 organize.manual.run 时按方案自己校验——
        官方模板也是直接把 profileId 交给宿主，从不预检目标目录。
        """
        try:
            profiles = ctx.mt.organize.profiles()
        except SDKError as error:
            message = f"无法读取整理方案（{error.code}），请检查 organize.read 授权"
            ctx.mt.log(level="error", message=message)
            raise SDKError(message, "NO_PROFILE") from error

        found = None
        for profile in profiles or []:
            if int(profile.get("id", 0)) == profile_id:
                found = profile
                break
        if found is None:
            available = ", ".join(
                f"{item.get('id')} {item.get('name', '')}" for item in (profiles or [])[:10]
            ) or "无"
            message = f"找不到整理方案 {profile_id}。当前可用方案：{available}"
            ctx.mt.log(level="error", message=message)
            raise SDKError(message, "NO_PROFILE")

        name = found.get("name", "")
        if found.get("kind") != "organize":
            message = f"方案「{name}」不是整理方案（kind={found.get('kind')}）"
            ctx.mt.log(level="error", message=message)
            raise SDKError(message, "INVALID_PROFILE")
        if not found.get("enabled"):
            message = f"方案「{name}」已停用，请先在自动整理页面启用"
            ctx.mt.log(level="error", message=message)
            raise SDKError(message, "INVALID_PROFILE")

        source = found.get("source") or {}
        destination = found.get("destination") or {}
        ctx.mt.log(
            level="info",
            message=(f"使用方案「{name}」：源 {source.get('path', '-')} → "
                     f"目标 {destination.get('path', '-') if destination else '（宿主未返回）'}。"
                     "目标目录的写入权限由宿主在执行整理时校验。"),
        )
        return found

    def _notify_result(self, ctx: Context, counts: dict, mode: str,
                       profile_name: str, results: list[dict]) -> None:
        """把本轮结果发到通知通道。失败只记日志，绝不影响整理结果。"""
        if not self._notify_enabled(ctx):
            return
        try:
            title, body = notify.build_summary(counts, mode, profile_name, results)
            channel = self._notify_channel(ctx)
            if not channel:
                ctx.mt.log(level="warn", message="通知已开启但未选择通知通道，跳过发送")
                return
            ctx.mt.notification.send(channel_id=channel, title=title, content=body)
            ctx.mt.log(level="info", message=f"已发送结果通知：{title}")
        except SDKError as error:
            # 通知失败不能影响已经完成的整理
            ctx.mt.log(level="warn", message=f"发送通知失败 {error.code}：{error}")
        except Exception as error:  # noqa: BLE001
            ctx.mt.log(level="warn", message=f"发送通知异常：{type(error).__name__}")

    @staticmethod
    def _notify_enabled(ctx: Context) -> bool:
        """默认开启；只有显式配置为 false 才关闭。"""
        value = ctx.config.get("notifyEnabled")
        return True if value is None else bool(value)

    @staticmethod
    def _notify_channel(ctx: Context) -> str:
        """优先用配置里指定的通道；留空时用宿主授予的第一个通道。"""
        channel = ctx.config.get("notifyChannelId")
        if isinstance(channel, str) and channel.strip():
            return channel.strip()
        try:
            resources = ctx.mt.runtime.resources()
        except SDKError:
            return ""
        if not isinstance(resources, dict):
            return ""
        granted = resources.get("notificationChannelIds") or []
        for item in granted:
            if isinstance(item, str) and item:
                return item
            if isinstance(item, dict) and item.get("id"):
                return str(item["id"])
        return ""

    @staticmethod
    def _capabilities(ctx: Context) -> dict:
        try:
            return ctx.mt.ai.capabilities() or {}
        except SDKError as error:
            ctx.mt.log(level="warn", message=f"AI 能力查询失败 {error.code}")
            return {"chat": {"available": False, "reason": "unavailable"}}

    @staticmethod
    def _record(item: dict, status: str = "identified", reason: str = "") -> dict:
        return {
            "ref": item["ref"],
            "name": item.get("name", ""),
            "path": item.get("path", ""),
            "rootId": item.get("rootId", ""),
            "version": item.get("version", ""),
            "status": status,
            "reason": reason,
            "title": "",
            "originalTitle": "",
            "year": 0,
            "mediaType": "movie",
            "season": 0,
            "episode": 0,
            "tmdbId": 0,
            "multiEpisode": False,
            "confidence": 0.0,
            "aiUsed": False,
            "updatedAt": _now(),
        }

    @staticmethod
    def _counts(results: list[dict]) -> dict:
        counts = {"total": len(results), "matched": 0, "submitted": 0, "failed": 0,
                  "unrecognized": 0, "identity_conflict": 0, "needs_review": 0}
        for record in results:
            status = record.get("status")
            if status == "matched":
                counts["matched"] += 1
            elif status in ("submitted", "organized"):
                # 已提交的文件此前一定通过了 TMDB 核对，仍计入「可整理」
                counts["matched"] += 1
                counts["submitted"] += 1
            elif status == "identity_conflict":
                counts["identity_conflict"] += 1
            elif status == "needs_review":
                counts["needs_review"] += 1
            elif status == "unrecognized":
                counts["unrecognized"] += 1
            elif status == "failed":
                counts["failed"] += 1
        return counts

    # ---------------------------------------------------------------- 进度

    @staticmethod
    def _report(ctx: Context, stage: str, done: int, total: int, detail: str = "") -> None:
        """把阶段、进度和当前文件名推给宿主进度条。

        宿主只给 completed / total / message 三个字段，页面拿
        run.progress.message 当进度条 label，所以阶段与文件名都拼进 message。
        进度上报失败绝不能影响主流程。
        """
        text = f"{stage} {int(done)}/{int(total)}"
        clean = (detail or "").strip()
        if clean:
            if len(clean) > 56:
                clean = clean[:54] + "…"
            text = f"{text} · {clean}"
        try:
            ctx.mt.runtime.progress(completed=int(done), total=int(total), message=text)
        except SDKError:
            pass

    @staticmethod
    def _write_summary(ctx: Context, flow_key: str, summary: dict) -> None:
        ctx.mt.storage.set(key=f"runs/{flow_key}/summary", value={**summary, "updatedAt": _now()})

    def _patch_summary(self, ctx: Context, flow_key: str, patch: dict) -> None:
        entry = ctx.mt.storage.get(key=f"runs/{flow_key}/summary")
        current = entry["value"] if entry["found"] else {}
        self._write_summary(ctx, flow_key, {**current, **patch})

    @staticmethod
    def _persist(ctx: Context, flow_key: str, results: list[dict]) -> None:
        """逐文件分键写入，避免单个 KV 值随文件数增长。"""
        operations = []
        for index, record in enumerate(results):
            operations.append({
                "operation": "set",
                "key": f"runs/{flow_key}/items/{index:06d}",
                "value": record,
            })
            if len(operations) >= 50:
                ctx.mt.storage.batch(operations=operations)
                operations = []
        if operations:
            ctx.mt.storage.batch(operations=operations)

    @staticmethod
    def _save_flow(ctx: Context, flow_key: str, flow: dict) -> None:
        ctx.mt.storage.set(key=f"flows/{flow_key}", value={**flow, "updatedAt": _now()})

    @staticmethod
    def _load_flow(ctx: Context, flow_key: str) -> dict:
        entry = ctx.mt.storage.get(key=f"flows/{flow_key}")
        return entry["value"] if entry["found"] and isinstance(entry["value"], dict) else {}

    @classmethod
    def _patch_flow(cls, ctx: Context, flow_key: str, patch: dict) -> dict:
        current = cls._load_flow(ctx, flow_key)
        merged = {**current, **patch}
        cls._save_flow(ctx, flow_key, merged)
        return merged

    @staticmethod
    def _save_pending(ctx: Context, flow_key: str, files: list[dict]) -> None:
        for start in range(0, len(files), 100):
            chunk = files[start:start + 100]
            ctx.mt.storage.set(key=f"pending/{flow_key}/chunk/{start // 100:03d}", value=chunk)

    @staticmethod
    def _load_pending(ctx: Context, flow_key: str) -> list[dict]:
        files: list[dict] = []
        cursor = ""
        prefix = f"pending/{flow_key}/chunk/"
        while True:
            page = ctx.mt.storage.list(prefix=prefix, cursor=cursor, limit=50, values=True)
            for entry in page.get("items", []):
                files.extend(entry.get("value") or [])
            following = page.get("nextCursor", "")
            if not following or following == cursor:
                break
            cursor = following
        return files

    @staticmethod
    def _load(ctx: Context, flow_key: str) -> list[dict]:
        results: list[dict] = []
        cursor = ""
        prefix = f"runs/{flow_key}/items/"
        while True:
            page = ctx.mt.storage.list(prefix=prefix, cursor=cursor, limit=100, values=True)
            for entry in page.get("items", []):
                value = entry.get("value")
                if isinstance(value, dict):
                    results.append(value)
            following = page.get("nextCursor", "")
            if not following or following == cursor:
                break
            cursor = following
        return results
